
N=5 ;
td=1;
fs=10000;
f0=50;
n=1:N;
A=n.^-1;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
soundsc(xn,fs);
%% part b
N=5 ;
td=1;
fs=10000;
f0=50;
n=1:N;
A=n.^-2;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
soundsc(xn,fs);
%% partc1
N=10 ;
td=1;
fs=10000;
f0=100;
n=1:N;
A=n.^-1;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
soundsc(xn,fs);
%% partc2
N=10 ;
td=1;
fs=10000;
f0=100;
n=1:N;
A=n.^-2;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
soundsc(xn,fs);
%% partd
N=5 ;
td=1;
fs=10000;
f0=50;
n=1:N;
A=sin(pi*n*(1/N));
P=n*0;
xn=harmonics(A,f0,P,td,fs);
soundsc(xn,fs);
%% part e
N=5 ;
td=1;
fs=10000;
t=0:1/fs:1;
f0=50;
n=1:N;
A=n.^-2;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
n=0:499;
t_samples=n/fs;
plot(t_samples,xn(1:500));
xlabel('t')
ylabel('x(t)')
title("plot for ak=(1/n)*(1/n)");
