
function xn = SineSum(A, F, P, td, fs)
N=td*fs;
n=0:N-1;
t_samples=n/fs;
xn=zeros(size(n));
for k=1:size(A,2)
   xn= xn+A(k)*sin((2*pi*F(k)*t_samples)+P(k)); 
end
end
