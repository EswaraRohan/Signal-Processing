function yn = my_synthesizer(A,F_notes,P,adsr,td_notes,fs)
M=length(F_notes);
y=[];
for n=1:M
  k=td_notes(n)/(sum(adsr)-adsr(3));
  xt=harmonics(A,F_notes(n),P,td_notes(n),fs);
[t_env,env] = envelope(k*adsr(1),k*adsr(2),adsr(3),k*adsr(4),k*adsr(5),fs);
  xte=xt(1:length(t_env)).*env;
    y=[y,xte];  
end
    yn=y;
end
