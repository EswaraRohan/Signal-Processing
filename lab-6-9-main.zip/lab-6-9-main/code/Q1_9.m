
td=4;
fs=10000;
F=[350 400];
P=[0 0];
A=[0.5 0.5];
xn = SineSum(A, F, P, td, fs);
%sound(xn,fs);
% part b%%
td=0.5;
fs=10000;
F1=[480 620];
F2=[0 0];
P=[0 0];
A=[0.5 0.5];
b1=SineSum(A, F1, P, td, fs);
z1=SineSum(A, F2, P, td, fs);
r2=[b1,z1];
g=[r2,r2];
x2=[g,g];
%sound(x2,fs);
% part c%%%
td=2;
fs=10000;
F1=[440 480];
F2=[0 0];
P=[0 0];
A=[0.5 0.5];
b2=SineSum(A, F1, P, td, fs);
z2=SineSum(A, F2, P, td, fs);
r3=[b2,z2];
g=[r3,r3];
x3=[g,g];
%sound(x3,fs);
% part e%%
n=0:499;
t_samples=n/fs;
subplot(3,1,1);
plot(t_samples,xn(1:500));
xlabel('t')
ylabel('xn')
title("plot of xn");
subplot(3,1,2);
plot(t_samples,x2(1:500));
xlabel('t')
ylabel('x2')
title("plot of x2");
subplot(3,1,3);
plot(t_samples,x3(1:500));
xlabel('t')
ylabel('x3')
title("plot of x3");


%%%%%%%%%%  Observation   %%%%%%%%%%%%%
% The sounds are very familiar. They are telephone ring sounds
