function xn = harmonics(A, f0, P, td, fs)
n=1:size(A,2);
F=n*f0;
xn=SineSum(A,F,P,td,fs);
end
