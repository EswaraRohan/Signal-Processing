
N=5 ;
td=1;
fs=10000;
f0=50;
n=1:N;
A=n.^-1;
P=n*0;
xn=harmonics(A,f0,P,td,fs);
[t_env,env] = envelope(0.2,0.2,0.7,0.4,0.2,fs);
%soundsc(xn,fs);
soundsc(xn.*env,fs);
figure(1);
subplot(3,1,1);
plot(xn);
xlabel('t')
ylabel('xn')
title("Xn");

subplot(3,1,2);
plot(env);
xlabel('t')
ylabel('env')
title("ADSR Envelope");

subplot(3,1,3);
plot(xn.*env);
xlabel('t')
ylabel('xn.*env')
title("xn.*env");
