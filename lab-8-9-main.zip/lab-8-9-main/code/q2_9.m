x=-1.5:0.01:1.5;
y=x;
[X,Y] = meshgrid(x,y);
Z=X+1j*Y;

%%% Part A %%%

p=1+1j;
figure;
mesh(X,Y,log(abs(Z./(Z-p))));

P=0.9;
figure;
mesh(X,Y,log(abs(Z./(Z-p))));


%%% Part B %%%

p=1+1j;
syms x;
a=coeffs(x);
b=coeffs(x-p);
a=double(fliplr(a));
b=double(fliplr(b));
zplane(a,b);

p=0.9;
syms x;
a=coeffs(x);
b=coeffs(x-p);
a=double(fliplr(a));
b=double(fliplr(b));
zplane(a,b);


%%% Part C %%%

p = 0.9;
figure
freqz(1,[1,-p],1001,'whole');

p = 1+1j;
figure
freqz(1,[1,-p],1001);

%%% Part D %%%

n = 51;
p = 0.9;
figure
impz(1,[1,-p],n);

% There will be two possibilities for ROC in which impz choose |Z|>0.9 possibility other than |Z|<0.9

p = 1+1j;
figure
impz(1,[1,-p],n);

% There Will Be two possibilities for ROC in which impz choose |Z|>|1+j| possibility other than |Z|<|1+j|

%%% Part E %%%

r = 0.95;
theta = pi/3;


figure
mesh(x,y,log(abs(((Z.*Z)-(2*cos(theta)*Z)+1)./((Z.*Z)-(2*r*cos(theta)*Z)+(r*r)))));

figure
zplane([1,-2*cos(theta),1],[1,-2*r*cos(theta),r*r]);

figure
freqz([1,-2*cos(theta),1],[1,-2*r*cos(theta),r*r],1001);

figure
impz([1,-2*cos(theta),1],[1,-2*r*cos(theta),r*r],n); 


%%% Part F %%%

% zeroes=exp(j*theta),exp(-j*theta); 
% poles=r*exp(j*theta),r*exp(-j*theta); 

% Changing value of theta, they rotate around same distance from origin
% On Increasing r, Poles move farther from origin



