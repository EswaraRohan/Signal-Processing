function [N,ROC,roc_zero] = region_of_convergence(p)
 mag=abs(p);
 mag=unique(mag);
 if mag(1)==0
 N=length(mag);
 ROC=zeros(N,2);
 roc_zero=0;
 ROC(1,1)=0;
 ROC(N,2)=inf;
 for k=1:N-1
     ROC(k,2)=mag(k+1);
     ROC(k+1,1)=mag(k+1);
 end
 else
     N=length(mag)+1;
     roc_zero=1;
 ROC(1,1)=0;
 ROC(N,2)=inf;
 for k=1:N-1
     ROC(k,2)=mag(k);
     ROC(k+1,1)=mag(k);
 end
 end
 
 end
