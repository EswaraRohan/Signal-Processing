p=[1, -1, 2-1j, 2+1j];
[N,roc,roc_zero]=region_of_convergence(p);
disp(N);

disp(roc);

disp(roc_zero);
