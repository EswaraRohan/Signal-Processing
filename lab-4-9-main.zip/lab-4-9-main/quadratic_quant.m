function y=quadratic_quant(x,B,a)
n=size(x,2);
y=zeros(size(x));
l=2^(B-1);
temp=zeros(2*l+1);
for k=1:2*l+1
   if k<l+1
       temp(k)=a*(k-l-1)^2*(1/l)^2*-1;
       
   else
      temp(k)=a*(k-l-1)^2*(1/l)^2; 
       
   end
    
end


for t=1:n
for re=1:2*l
    if temp(re)<=x(t) && temp(re+1)>x(t)
        y(t)=-0.5* (temp(re)+temp(re+1));
        break;
    elseif x(t)>=a
        y(t)=a;
        break;
    elseif  x(t)<-a
        y(t)=-a;
        break;
        
    end

end
end
end
