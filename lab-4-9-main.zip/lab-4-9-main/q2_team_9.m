Fs=5*1000;
Ts=1/Fs;
time_samples=0:Ts:1;
f0=10;
xn=sin(2*pi*f0*time_samples);
y=quadratic_quant(xn,2,1);
subplot(2,1,1);
stem(time_samples,y);
xlabel('t');
ylabel('y[n]');
title('quantized signal');
subplot(2,1,2);
stem(time_samples,xn);
xlabel('t');
ylabel('x[n]');
title('sample signal ');

%%%%%%%%%%%%%%%  a=1, B=4%%%%%%%%%%%%%%%%%%%%%%%%%
Fs=5*1000;
Ts=1/Fs;
time_samples=0:Ts:1;
f0=10;
xn=sin(2*pi*f0*time_samples);
y=quadratic_quant(xn,4,1);
e=zeros(size(xn));
for k=1:size(xn,2)
 e(k)=y(k)-xn(k);   
end
subplot(3,1,1);
plot(time_samples,xn);
xlabel('t');
ylabel('x(t)');
title('sample signal');
subplot(3,1,2);
plot(time_samples,y);
xlabel('t');
ylabel('y(t)');
title('quantized signal');
subplot(3,1,3);
plot(time_samples,e);
xlabel('t');
ylabel('e(t)');
title('error');
%%%%%%%%%%%%%%%%%%%%%%% part d%%%%%%%%%%%%%%%%%%%%%%%%
Fs=5*1000;
Ts=1/Fs;
time_samples=0:Ts:1;
f0=10;
xn=sin(2*pi*f0*time_samples);
y1 = quadratic_quant(xn,3,1);
y4 = quadratic_quant(xn,4,1);

e = zeros(size(xn)) ;
err1 = zeros(size(xn)) ;
for k = 1 : size(xn,2)
    err1(k) = y1(k) - xn(k);
    e(k) = y4(k) - xn(k);
end

subplot(2,1,1);
histogram(e,15);
xlabel('t');
ylabel('e_q[n]');
title('B = 4 ');
subplot(2,1,2);
histogram(err1,15);
xlabel('t');
ylabel('e_q[n]');
title('B = 3');



%%%%%%%%%%%%%%%%%%5%%%%%%%%% part e  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
figure(3);
a = 1 
temp=0
MaximError = zeros (8,1);
for B = 1 : 8 
     y = quadratic_quant(xn,B,a);
     temp = max(abs(xn - y));
     MaximError(B)= temp ;
end
k = 1:1:8 ;
stem(k,MaximError);
xlabel('B');
ylabel('MAE');
title('Maximum Absolute Error (B=1 TO B=8)');
display(MaximError);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%% sqnr%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Fs=5*1000;
Ts=1/Fs;
B=1:8;
time_samples=0:Ts:1;
f0=10;
xn=sin(2*pi*f0*time_samples);


xt=zeros(size(xn,2));
et=zeros(size(xn,2));
sqrn=zeros(max(B));
for n=B
    xt=quadratic_quant(xn,n,1);
    et=xn-xt;
    error=0;
    ab=0;
    for l=1:size(xn,2)
        error=error+abs(et(l))^2;
        ab=ab+abs(xn(l))^2;
    end
    sqrn(n)=ab/error;
    
    
    
end
plot(B,sqrn);
xlabel('B');
ylabel('sqrn');
title('sqrn plot ');
%%%%%%%%%%%%%%%% part g%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Fs=5*1000;
Ts=1/Fs;
time_samples=0:Ts:1;
f0=10;
xn=sin(2*pi*f0*time_samples);
yq=quadratic_quant(xn,4,1);
yl=linear_quant(xn,4,1);
eq=zeros(size(xn));
el=zeros(size(xn));
for k=1:size(xn,2)
 eq(k)=yq(k)-xn(k);
 el(k)=yl(k)-xn(k);
end

subplot(2,1,1);
plot(time_samples,eq);
xlabel('t');
ylabel('eq(t)');
title('error in quadratic quantization');
subplot(2,1,2);
plot(time_samples,el);
xlabel('t');
ylabel('el(t)');
title('error in linear quantization');




function y=linear_quant(x,B,a)
n=size(x,2);
y=zeros(size(x));
l=2^(B-1);
temp=zeros(2*l+1);
for k=1:2*l+1
   if k<l+1
       temp(k)=a*(k-l-1)*(1/l)*-1;
       
   else
      temp(k)=a*(k-l-1)*(1/l); 
       
   end
    
end


for t=1:n
for re=1:2*l
    if temp(re)<=x(t) && temp(re+1)>x(t)
        y(t)=0.5* (temp(re)+temp(re+1));
        break;
    elseif x(t)>=a
        y(t)=a;
        break;
    elseif  x(t)<-a
        y(t)=-a;
        break;
        
    end

end
end
end
%%%%%%%%%%%%%%%%%% observations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%  Part d %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Histogram with B = 4 is more uniform and has less error to B = 3


%%%%%%%%%%%%%%%%%%%%%%%%%%  Part e %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% As B is Increasing, MAE is also increasing


%%%%%%%%%%%%%%%%%%%%part f %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%from the plot we can clearly say that as B increases the sqrn also increases as signal power is constant
% so that means quantization noise power decreases so as B increases noise decreases

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% part g %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% quadratic quantization accuracy is not that good in [-a,a) as there is non zero error at almost all places
% and where in linear quantizationa at some places the error is very large compared to quadratic and in linear the error is more than quadratic 
