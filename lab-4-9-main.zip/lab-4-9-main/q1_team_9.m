clc;
clear all;
close all;
%%%%%%%%%%%%%%%%%%%% bitrates %%%%%%%%%%%%%%%%%%%%%%%
% 1mb  256kbps
% 2mb  512kbps
% 5mb  1411kbps
% 10mb 1411kbps


%%%% 4.1 find fs %%%%%%%%%%%%%%%%%%%%%%%%
[y1,fs1]=audioread('file_example_WAV_1MG.wav');
disp(fs1);


%%%%%%%%%%% findidng duration %%%%%%%%%%%%
Ts1=1/fs1;
d1=Ts1*(size(y1,1)-1);%duration=Ts * (no.of samples-1)
disp(d1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%bit rate quantization level%%%%%%%%

br=256*1000;%bit rate
b=br/(fs1*2);%bits=b rate/fs*no.ofchannels
disp(b);
qu=2^b;%quantization level =2^no.of bits
disp(qu);

%%%%%%%%%%%%%%%%%%%%% sound() %%%%%%%%%%%%%%%%%%%%%%%%%%
sound(y1);

%%%%%%%%%%%%% low fs        %%%%%%%%%%%%%%
sound(y1,0.9*fs1);
sound(y1,0.8*fs1);
sound(y1,0.7*fs1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% high fs  %%%%%%%%%%%%%%%%

sound(y1,1.2*fs1);
sound(y1,1.4*fs1);
sound(y1,1.6*fs1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% observation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  as Fs changes %%%%%%%%%%%%%%%%%%%%%%%
% fs decreases the audio signal also slow downs
% fs increases the audio signal becomes quick

%%%%%%%%%% fourier property %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the property is here is time scaling
% as sampling frequency increase amplitude in frequency domain also increases
