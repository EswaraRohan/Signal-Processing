clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%% quantization at B=3%%%%%%%%%%%%%%%%
[y1,fs1]=audioread('file_example_WAV_1MG.wav');
y1=transpose(y1);
y2=quadratic_quant(y1,3,1);
sound(y2,fs1);
%%%%%%%%%%%%%%%%%%%%%%%%%% for loop%%%%%%%%%%%%%%%%%%
B=1:8;
[y1,fs1]=audioread('file_example_WAV_1MG.wav');
y1=transpose(y1);
for n=B
    
    y2=quadratic_quant(y1,n,1);
     sound(y2,fs1);
     
    pause(2);
    
    
    
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%% observations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for B=3 the quality of the signal isbad compared to original signal
% as B increases the quality of the signal becomes better and better
%As B increases it gives higher resolution by increase in no. of quant. intervals  and quant. levels
