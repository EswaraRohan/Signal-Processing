%As the function is an even function there are only real part but no imaginary part
%so we plot only real part
%the symmetry is working.
%to check for imaginary part of coefficient add imag (in the line co(n+N+1)=(1/T)*imag(int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2)) ) and run 
%the plot will be for imaginary values



%Declaring variables
syms t;
T=1;
N=20;
t2=(T/4);
t1=(-1)*t2;

%Function Expression
ft=abs(t);


%Function Call
  co=fourierCoeff(t,ft,T,t1,t2,N); 

    %Plotting Graph
    x_axis=-N:N;
    figure;
    stem(x_axis,co);
    xlabel('Integers')
    ylabel('Fourier Coefficients')
    title("PLOT")
    grid on;
  
  
function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
%For loop to find the coefficients of k value -N to N
for n=-N:N
  %co(n+N+1)=(1/T)*imag(int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2));
  co(n+N+1)=(1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2);
end   
end


     %>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Result<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<%
     %All the Imaginary values are zero and the symmetry works as it is a even function  
     %you can check that in the picture in the result with name Question 4 Part A (Real).fig and Question 4 Part (Imag).fig
     %>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<%
