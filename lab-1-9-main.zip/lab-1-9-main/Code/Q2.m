% declare the function xt,and other variables

syms t;
T=1;
N=5;
t2=(T/2);
t1=(-1)*t2;
time_grid=-0.5:0.01:0.5;
  
% Function Expression
ft=2*(cos(2*pi*t))+cos(6*pi*t);
ft_1=2*(cos(2*pi*time_grid))+cos(6*pi*time_grid);

% Function Call
   co=fourierCoeff(t,ft,T,t1,t2,N); 
   y = partialfouriersum (co, T, time_grid,N);

% Plotting The Graph
%subplot function is used since we needed multiple graphs in one fig.

  subplot(2,1,1);
  plot(time_grid,ft_1,'b');
  xlabel('time t')
  ylabel('f(t)')
  title("original")
  
  subplot(2,1,2);
  plot(time_grid,y,'r');
  xlabel('time t')
  ylabel('f(t)')
  title("constructed")

%Displaying Of MAX Error
MAX=max(y-ft_1); 
disp(MAX);

%Displaying Of RMS Error(Most Reliable)
RMS = sqrt(mean(y-ft_1).^2);
disp(RMS);

%Function Declaration

%Fouriercoeff Function
function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
% For loop to find the coefficients of k value -N to N
for n=-N:N
  co(N+1+n)=((1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2));
end   
end

%PartialFourierCoeff Function
function y = partialfouriersum (co, T, time_grid,N)
y=zeros(size(time_grid));
w0=2*pi/T;
for h=-N:N
    y=y+real((co(h+N+1)*exp(1i*w0*h*time_grid)));
end
end


%>>>>>>>>>>>>>>>>>>>Result<<<<<<<<<<<<<<<<<<<<<<<<<
%the both constructed and the original are approximatly same 
%there is very slight difference original and constucted with is multiple of e^-16
%>>>>>>>>>>>>>>>>>>>>>>>END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
