%declaring the variables
T1=0.1;
t1=-T1;
t2=T1;
T=1;
N=150;
time_grid=-0.5:0.01:0.5;
syms t;
ft=1;
ft_1 = piecewise(t>-T1 & t<T1,1,0);%lets take amplitude to be 1


   


%functional call for part c
co=fourierCoeff(t,ft,T,t1,t2,N);

%functional call for part c
y = partialfouriersum (co, T, time_grid,N);
%ploting the graph
 
 

 % ploting the graph for the the part c in the 1.3

   

 plot(time_grid,y,'r');
  xlabel('the value of k')
    ylabel('f(t)')
    title("reconstucted ft")


function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
% lets use for loop to find the coefficients of k value -N to N
for n=-N:N
  co(N+1+n)=((1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2));
end   
end

%partialsumfunction

function y = partialfouriersum (co, T, time_grid,N)
y=zeros(size(time_grid));
w0=2*pi/T;
for h=-N:N
    y=y+real((co(h+N+1)*exp(1i*w0*h*time_grid)));
end
end


%>>>>>>>>>result<<<<<<<<<<<<%
% AS THE N VALUE INCREASES THE PLOT OF CONSTRUCTED FUNCTION BECAME MORE AND MORE SQUARE AND BECOMES SIMILAR TO THE ORIGINAL SQUARE WAVE
%HERE WE TAKE F(T)=1 BECASE BY USING t1 and t2 WE CAN FIND FOURIRER COEFFICIENTS FOR THE ORIGINAL SQURE WAVE
%YOU CAN OBSERVE THAT IN THE .FIG FILES UPLOADED IN THE RESULT FOLDER
%>>>>>>>>>>>>>END<<<<<<<<<%
