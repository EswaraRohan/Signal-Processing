%Variables Declaration

syms t;
T=1;
N=10;
t2=0.25;
t1=-0.25;

%Expression of the funuction
ft=1;

  %Function Call
  co=fourierCoeff(t,ft,T,t1,t2,N);  

    %Ploting The Graph
    x_axis=-N:N;
    figure;
    stem(x_axis,co);
    xlabel('Integers')
    ylabel('Fourier Coefficients')
    title("PLOT")
    grid on;
  
function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
%For loop to find the coefficients of k value -N to N
for n=-N:N
  co(n+N+1)=(1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2);
end   
end

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>result<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
%it is a even function so the imaginary part of the all the fourier coefficients is equal to zero.
%so we plot only for real coefficient
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
