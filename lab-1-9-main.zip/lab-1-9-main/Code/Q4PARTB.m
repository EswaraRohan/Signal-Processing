
%As the function is an odd function there are only imaginary part but no real part
%so we plot only imaginary part
%the symmetry is working.
%to check for real part of coefficient remove imag(in the line co(n+N+1)=(1/T)*imag(int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2)) ) and run 
%the plot will be for real values

% declare the function xt,and other variables
syms t;
T=1;
N=10;
t2=0.25;
t1=-0.25;

% writing the expression of the funuction
ft=t;

  % functional call
  co=fourierCoeff(t,ft,T,t1,t2,N); 

    %lets plot the graph
    x_axis=-N:N;
    figure;
    stem(x_axis,co);
    grid on;
    
    
  % declaring the function
function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
% lets use for loop to find the coefficients of k value -N to N
for n=-N:N
  co(n+N+1)=(1/T)*imag(int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2));
end   
end
     %>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Result<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<%
     %All the real values are zero and the symmetry works as it is a odd function  
     %You can check that in the picture in the result with name Question 4 Part B (Imag).fig and Question 4 Part B (real).fig
     %>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<%
