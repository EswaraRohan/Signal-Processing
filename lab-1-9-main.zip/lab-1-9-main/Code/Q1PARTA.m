%Declaring variables

syms t;
T=1;
N=5;
t2=(T/2);
t1=(-1)*t2;

%Function Expression
ft=2*(cos(2*pi*t))+cos(6*pi*t);

%Function Call
  co=fourierCoeff(t,ft,T,t1,t2,N); 

    %Plotting Graph
    x_axis=-N:N;
    figure;
    stem(x_axis,co);
    xlabel('Integers')
    ylabel('Fourier Coefficients')
    title("PLOT")
    grid on;
  
function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
%For loop to find the coefficients of k value -N to N
for n=-N:N
  co(n+N+1)=(1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2);
end   
end

%>>>>>>>>>>>>>>>>>>>>>>>>>>>>result<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
%it is a even function so the imaginary part of the all the fourier coefficients is equal to zero.
%so we plot only for real coefficients
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
