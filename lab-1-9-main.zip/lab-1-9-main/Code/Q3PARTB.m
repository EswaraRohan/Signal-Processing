%Declaration Of Variables
t2=T1;
T=30;
N=50;
syms t;
ft=1;%amplitude of the square wave be 1 

%functional call for part c
co=fourierCoeff(t,ft,T,t1,t2,N);

 % ploting the graph for the the part b in the 1.3
    x_axis=-N:N;
    figure;
    stem(x_axis,co);
    grid on;
    xlabel('the value of k')
    ylabel('fourier coefficients')
    title("fourier coefficients for ft")




function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
% For loop to find the coefficients of k value -N to N
for n=-N:N
  co(N+1+n)=((1/T)*(int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2)));
end   
end
