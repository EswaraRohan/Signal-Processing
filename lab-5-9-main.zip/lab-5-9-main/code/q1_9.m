clc;
close all;
clear all;
w=-10:0.01:10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=0:0;
x=(T*0)+1;
N0=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=-3:1:3;
x=zeros(size(T));
x(1)=1;
N0=4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=-3:1:3;
x=(T*0)+1;
N0=4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=-200:200;
x=sin(pi*0.25*T);
N0=201;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X=DT_Fourier(x,N0,w);

figure(1);

subplot(2,2,1);
plot(w,abs(X));
xlabel('w')
ylabel('Magnitude')
title("Magnitude");


subplot(2,2,2);
plot(w,angle(X));
xlabel('w')
ylabel('Phase')
title("Phase");


subplot(2,2,3);
plot(w,real(X));
xlabel('w')
ylabel('Real Part')
title("Real Part");

subplot(2,2,4);
plot(w,imag(X));
xlabel('w')
ylabel('Imaginary Part')
title("Imaginary Part");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  part c  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%b=0.01;
%b=0.5;
b=0.99;
T=0:1:100;
N0=1;
a=b;
x2=a.^T;
X2=DT_Fourier(x2,N0,w);
x1=(-a).^T;
X1=DT_Fourier(x1,N0,w);
figure(2);
subplot(2,2,1);
plot(T,x2);
xlabel('n')
ylabel('a^nu[n]');


subplot(2,2,2);
plot(T,x1);
xlabel('n')
ylabel('(-a)^nu[n]')


subplot(2,2,3);
plot(w,abs(X2));
xlabel('w')
ylabel('magnitude of DTFT')

subplot(2,2,4);
plot(w,abs(X1));
xlabel('w')
ylabel('magnitude of DTFT')
%%%%%  observations %%%%%%%%%%%%%%%%%%%%%%%%%
%they are same as discussed in the class but there is small error in the plots 
%as b inncreses from 0.01 t0 0.99 we can observe that slope at 0 decreses and the after 0 the slope is goes t0 zero as b decreses
%and magnitude of DTFT increses as b increses and the width of each loab decreases


