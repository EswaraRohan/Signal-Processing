clc;
clear all;
close all;
t=0:1:1000;
w0=pi/200;
s=5*sin(w0*t);
v=randn(size(t));
x=s+v;
figure(1);
subplot(2,2,1);
plot(t,x);
hold on;
plot(t,s);
hold off;
xlabel('n')
title("original and noisy signal");
legend('noisy','original');

M =5;
u=0:1:M-1;
h=((u*0)+1)/M;
y=conv(x,h,'full');
subplot(2,2,2);
plot(t,s);
hold on;
plot(t,y(1:length(t)));
hold off;
xlabel('n')
title("M=5")
legend('original','filtered');


M1 =21;
u1=0:1:M1-1;
h1=(u1*0)+(1/M1);
y1=conv(x,h1,'full');
subplot(2,2,3);
plot(t,s);
hold on;
plot(t,y1(1:length(t)));
hold off;
xlabel('n')
title("M=21")
legend('original','filtered');


M2 =51;
u2=0:1:M2-1;
h2=(u2*0)+(1/M2);
y2=conv(x,h2,'full');
subplot(2,2,4);
plot(t,s);
hold on;
plot(t,y2(1:length(t)));
hold off;
xlabel('n')
title("M=51")
legend('original','filtered');


w=-10:0.01:10;
X=DT_Fourier(x,1,w);
Y=DT_Fourier(y,1,w);
Y1=DT_Fourier(y1,1,w);
Y2=DT_Fourier(y2,1,w);
figure(2);
subplot(2,2,1);
plot(w,abs(X));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of x[n]');

subplot(2,2,2);
plot(w,abs(Y));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of y[n] M=5');

subplot(2,2,3);
plot(w,abs(Y1));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of y[n] M=21');
subplot(2,2,4);
plot(w,abs(Y2));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of y[n] M=51');
t=0:1:1000;
w0=pi/200;
s1=sin(w0*t);
v1=randn(size(t));
x1=s1+v1;
figure(3);
subplot(2,1,1);
plot(t,x1);
hold on;
plot(t,s1);
hold off;
xlabel('n')
title('x[n] and s[n]');
legend('noisy','original');

u=0:1:1;
h3=zeros(size(u));
h3(1)=1;
h3(2)=-1;

y3=conv(x1,h3,'full');
subplot(2,1,2);
plot(t,s1);
hold on;
plot(t,y3(1:length(t)));
hold off;
xlabel('n')
title('s[n] and y[n]');
legend('original','filtered');



w=-10:0.01:10;
X=DT_Fourier(x,1,w);
Y3=DT_Fourier(y3,1,w);
figure(4);
subplot(2,1,1);
plot(w,abs(X));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of x[n]');
subplot(2,1,2);
plot(w,abs(Y3));
xlabel('w')
ylabel('Magnitude Of DTFT')
title('DTFT of y[n]');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Observations  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%     Part a   %%%%%%%%%%

%Check in result folder (Q2_a)

%%%%%%%%%%   Part e    %%%%%%%%%%%
% increasing 'm' betters the noise filtering
% Trade Off: Phase is changed

%%%%%%%%%%  Part f     %%%%%%%%%%%
% This moving average filter allows only certain frequencies to pass
% increasing 'm' betters the filtering


%%%%%%%%   Part g    %%%%%%%%%%%
% h(n) = δ(n)-δ(n-1)
% This filter will not give graph of original s[n] as difference between two consecutive values is obtained.
%Even though the random value graph is similar to that of original, the passing frequencies are wider in range

%%%%%%%   Part h   %%%%%%%%%%%%%
%  The nature of above implemented filters is 'low pass'. 
%  Differentiator has broader frequency range 







