%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Aliasing   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t_fine = 0:0.001:2;


figure(1);

subplot(2,2,1);
Ts = 0.1;
t_samples = 0:Ts:2;
xn = cos(5*pi*t_samples);
n = 0:2/Ts;
xrecon1 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon1,'r');
plot(t_samples,xn,'b')
xlabel('t')
ylabel('yt')
title("Sampling Interval = 0.1");
hold off;



subplot(2,2,2);
Ts = 0.2;
t_samples = 0:Ts:2;
xn = cos(5*pi*t_samples);
n = 0:2/Ts;
xrecon2 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon2,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Sampling Interval = 0.2");
hold off;



subplot(2,2,3);
Ts = 0.3;
t_samples = 0:Ts:2;
xn = cos(5*pi*t_samples);
n = 0:2/Ts;
xrecon3 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon3,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Sampling Interval = 0.3");
hold off;



subplot(2,2,4);
Ts = 0.4;
t_samples = 0:Ts:2;
xn = cos(5*pi*t_samples);
n = 0:2/Ts;
xrecon4 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon4,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Sampling Interval = 0.4");
hold off;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% observations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                                         %% Ans For Part A %%
                                         
%The Nyquist rate or frequency is the minimum rate at which a finite bandwidth signal needs to be sampled to retain all of the information
%It is formulated as 2*wm where wm is maximum frequency which is 2*pi/T 

%In the given question, x(t) = cos(5*pi*t). Fundamental period of cosine function is 2*pi/Theta
%So fundamental period of x(t) is (2*pi)/(5*pi) = 2/5.
%Therefore  wm = (2*pi)/(2/5) = (5*pi)
%Hence Nyquist frequency is 5*2*pi = 10*pi



                                     %% Observations For Part C %%
                                     
%As sampled time inteval is increasing margin of error is becoming large between original signal and constructed signal..
%For Ts=0.4 the error in the amplitude is large as compared to Ts = 0.1 which implies margin of error in case of amplitude increase as Ts increases. 
