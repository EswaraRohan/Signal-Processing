t_fine = 0:0.001:2;
xt = cos(5*pi*t_fine)+sin(10*pi*t_fine);

Ts = 0.1;
t_samples = 0:Ts:2;
xn = cos(5*pi*t_samples)+sin(10*pi*t_samples);
x1 = interp1(t_samples,xn,t_fine,"previous");
x2 = interp1(t_samples,xn,t_fine,"linear");

n = 0:2/Ts;
xr = sinc_recon(n,xn,Ts,t_fine);


figure(1);

subplot(2,2,1);
plot(t_fine,xt,'r')
xlabel('t')
ylabel('xt')
title("Normal Signal");


subplot(2,2,2);
plot(t_fine,x1,'b')
xlabel('t')
ylabel('xn')
title("Zero Order Reconstruction");


subplot(2,2,3);
plot(t_fine,x2,'b')
xlabel('t')
ylabel('xn')
title("First Order Reconstruction");


subplot(2,2,4);
plot(t_fine,xr,'b');
xlabel('t')
ylabel('xr')
title("ideal Reconstruction");


index = ((0.25 <t_fine) < 1.75);
MAE1 = max(abs(x1(index)-xt(index)));
disp(MAE1);
MAE2 = max(abs(x2(index)-xt(index)));
disp(MAE2);
MAE3 = max(abs(xr(index)-xt(index)));
disp(MAE3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% observation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Maximum Absolute Error for the three constructions are:
% Zero Order Reconstruction - 1.7601
% First Order Reconstruction - 1.2076
% Ideal Reconstruction - 1.0769
% Here the order of the MAE is Zero-Order > First-Order > Ideal

% Reconstuction graph is similar to the orginal graph and from that we can say Ideal reconstruction is the best method 
% Quality for ideal constuction is great compared to the other method as the reconstucted signal have  graph almost same as the original signal.
% Sampling at a rate above the Nyquist rate, further increase in the sampling frequency do not improve the quality of the reconstructed signal.
