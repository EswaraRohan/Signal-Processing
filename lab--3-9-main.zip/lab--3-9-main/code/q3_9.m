t_fine = -10:0.001:10;


figure(1);

subplot(2,2,1);
Ts = 0.5;
t_samples = -1:Ts:1; 
xn = 1-abs(t_samples);
n = -1/Ts:1:1/Ts;
xrecon1 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon1,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Ts = 0.5");
hold off;


subplot(2,2,2);
Ts = 0.2;
t_samples = -1:Ts:1; 
xn = 1-abs(t_samples);
n = -1/Ts:1:1/Ts;
xrecon2 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon2,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Ts = 0.2");
hold off;


subplot(2,2,3);
Ts = 0.1;
t_samples = -1:Ts:1; 
xn = 1-abs(t_samples);
n = -1/Ts:1:1/Ts;
xrecon3 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon3,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Ts = 0.1");
hold off;


subplot(2,2,4);
Ts = 0.05;
t_samples = -1:Ts:1; 
xn = 1-abs(t_samples);
n = -1/Ts:1:1/Ts;
xrecon4 = sinc_recon(n,xn,Ts,t_fine);
hold on;
plot(t_fine,xrecon4,'r');
plot(t_samples,xn,'b');
xlabel('t')
ylabel('yt')
title("Ts = 0.05");
hold off;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% observation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% By looking at the plots corresponding to Ts = 0.5, 0.2, 0.1, 0.05; As Ts is decreasing the margin of error between 
% Reconstructed signal and Sampling signal is decreased.
