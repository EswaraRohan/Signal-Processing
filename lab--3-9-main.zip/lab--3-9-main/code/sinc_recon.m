function xr = sinc_recon(n,xn,Ts,t_fine)

ws = 2*pi/Ts;
wc = ws/2;
xr = zeros(size(t_fine));
z = n(1);
for y = n 
    xr = xr + (Ts.*xn(y-z+1).*sin(wc.*(t_fine-y*Ts))./(pi.*(t_fine-y.*Ts)));
end
end