%3.1 
%PartA

t_fine = 0:0.001:2;
figure(1);
xt = cos(5*pi*t_fine)+sin(10*pi*t_fine);
plot(t_fine,xt)
xlabel('t')
ylabel('xt')
title("Normal Signal");


%PartB
Ts = 0.1;
t_samples = 0:Ts:2;
figure(2);
xn = cos(5*pi*t_samples)+sin(10*pi*t_samples);
stem(t_samples,xn)
xlabel('t')
ylabel('xn')
title("Sampled Signal");
