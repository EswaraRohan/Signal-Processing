syms t ;
w=-5:0.1:5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  part b         %%%%%%%%%%%%%%%%%%
T=2;
xt=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   part c T=1     %%%%%%%%%%%%%%%%%%
T=1;
xt=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  part c T=4      %%%%%%%%%%%%%%%%%%
T=4;
xt=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  part d e^(jt)   %%%%%%%%%%%%%%%%%%
T=pi*1;
xt=exp(1i*t);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  part d cos(t)   %%%%%%%%%%%%%%%%%%
T=pi*1;
xt=cos(t);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%    part e     %%%%%%%%%%%%%%%%%%%%
T=1;
xt= 1-abs(t);
a=-1 * T;
b=T;

%functional call
X=countinuousFT(t,xt,a,b,w);

   subplot(2,2,1);
       plot(w,X);
       xlabel('w');                            
       ylabel('realpart(X) ');                   
       title('real part of the computed FT');
       
   subplot(2,2,2);
       plot(w,imag(X));
       xlabel('w');                           
       ylabel('imagpart(X) ');                    
       title('imaginary part of the computed FT');
       
   subplot(2,2,3);
      plot(w,abs(X));
      xlabel('w');                         
      ylabel('absolute(X) ');                     
      title(' absolute of the computed FT');
      
   subplot(2,2,4);
     plot(w,angle(X));
     xlabel('w');                        
     ylabel('phase(X) ');                    
     title('phase of the computed FT');      
     

%%%%%%%%%%%%%%%%function for part a %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function declaration 
function X =countinuousFT(t,xt,a,b,w)
X=zeros(size(w));
X = (int(xt*(exp(1i * w * t)),t,a,b));%integralof (xt*e^(jwt))between [a,b]
end 



%%%%%%%%%%%%%%%%%%%%% Result - Part B %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%First graph represents real part and it's non zero and imaginary graph is non zero
%The absolute graph is the mod of the real graph
%In Case Of phase graph, if x > 0 the phase is zero and if x< 0 phase is pi 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%% Result - Part C  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%When T is changed from 1 to 4, Amplitude increases by scaling factor, T increases. Here TIME SCALING Property is observed.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%% Result - Part D %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%We are expecting the fourier transform to be with impulses but we donot get the impulses because we integrated from -T to T 
%If we integrate from -inf to inf we will get impulses

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%  Result - Part E %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Expected Fourier Transform is - sinc^2=sinc * sinc 
%But sinc is the FT of a rectangular pulse
%The xt is is convolusion of a rectangular pulse on itself.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
