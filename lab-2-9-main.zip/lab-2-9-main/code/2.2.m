
syms t;
N=10;


%%%%%%%%%%%%%%%%%%%%%     part b    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft=cos(t);
wc =2;
w0_FS=1;
T=2* pi;
t1=-(0.5)*T;
t2=(0.5)*T;
time_grid=-2*T:0.01:2*T;
A=fourierCoeff(t,ft,T,t1,t2,N);
y1=partialfouriersum(A,T,time_grid,N);
B = myLPF(A,w0_FS,wc);
y2=partialfouriersum(B,T,time_grid,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%   part c    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft=cos(t);
wc =2;
T=2* pi;
w0_FS=1;
t1=-(0.5)*T;
t2=(0.5)*T;
time_grid=-2*T:0.01:2*T;
A=fourierCoeff(t,ft,T,t1,t2,N);
y1=partialfouriersum(A,T,time_grid,N);
B = myHPF(A,w0_FS,wc);
y2=partialfouriersum(B,T,time_grid,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%     part   d    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft=cos(t);
G=1;
a=1;
wc =2;
T=2* pi;
w0_FS=1;
t1=-(0.5)*T;
t2=(0.5)*T;
time_grid=-2*T:0.01:2*T;
A=fourierCoeff(t,ft,T,t1,t2,N);
y1=partialfouriersum(A,T,time_grid,N);
B = (NonIdeal(A,w0_FS,G,a));
y2=partialfouriersum((B),T,time_grid,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%     part e    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft=sin(2*t)+cos(3*t);
T=2* pi;
w0_FS=1;
wc =2.5;
t1=-(0.5)*T;
t2=(0.5)*T;
time_grid=-2*T:0.01:2*T;
A=fourierCoeff(t,ft,T,t1,t2,N);
y1=partialfouriersum(A,T,time_grid,N);
%%%%%%%%%%%%%%%%%% for high pass filter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B = myHPF(A,w0_FS,wc);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  low pass filter %%%%%%%%%%%%%%%%%%
B = myLPF(A,w0_FS,wc);

y2=partialfouriersum(B,T,time_grid,N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


     subplot(2,1,1);
        plot(time_grid,y1,'r');
        xlabel('time--->');                            
        ylabel('x(t)--->');                     
        title('constructed from input');
     subplot(2,1,2);
        plot(time_grid,y2,'b');
        xlabel('time--->');                            
        ylabel('x(t)--->');                     
        title('constructed from output');



function co=fourierCoeff(t,ft,T,t1,t2,N)
   co=zeros(2*N+1,1);
   
for n=-N:N
  co(N+1+n)=((1/T)*int(ft*exp(-1i*(n)*(2*pi/T)*t),t,t1,t2));
end   
end

function y = partialfouriersum (co, T, time_grid,N)
y=zeros(size(time_grid));
w0=2*pi/T;
for h=-N:N
    y=y+real((co(h+N+1)*exp(1i*w0*h*time_grid)));
end
end



%%%%%%%%%%%%%%%%%%% part A function%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function B = myLPF(A,w0_FS,wc)
B = zeros(size(A));
N = max((size(A)-1)/2);
for k = -N:N
    if abs(k*w0_FS) <= wc
        B(k+N+1) = A(k+N+1);
    else 
        B(k+N+1)=0;
    end
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  part c function%%%%%%%%%%%%%%%%%%%
function B = myHPF(A,w0_FS,wc)
B = zeros(size(A));
N = max((size(A)-1)/2);
for k = -N:N
    if abs(k*w0_FS) >= wc
        B(k+N+1) = A(k+N+1);
    else 
        B(k+N+1)=0;
    end
end
end


%%%%%%%%%%%%%%%%%%%%% part d function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function B =NonIdeal(A,w0_FS,G,a)
B=zeros(size(A));
N=  max(size(A)-1)/2;

for k=-N:N
  Hw=  G/(a+(1i*w0_FS*k));
  B=Hw*A;
end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Part B Result%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if we change wc to 0.5 the wc<1 and wc<w0_FS so the only coefficient transmitted through filter is A0
% but A0=0  so the output signal is coincides with X-axis.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Part C Result%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The exact opposite of Part B result happens in part C as it's high pass filter.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Part D Result%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If LTI system has no complex nature, if the input is real then the output is also real 
%If LTI system has complex nature, if the input is real then the output have imaginary nature.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
