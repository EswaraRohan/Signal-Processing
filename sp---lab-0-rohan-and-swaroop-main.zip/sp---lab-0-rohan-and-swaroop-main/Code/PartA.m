clc;
clear all;
close all;

A = rand(5,5); % Generates A Random 5×5 Matrix

disp(A);

B = A(3:5,3:5); % Assignes Bottom Right 3×3 SubMatrix Of A To B
disp(B);

S = sum(B,'all'); % sum(Matrix,'all') Function Sums Up All Entries Of S
disp(S);
