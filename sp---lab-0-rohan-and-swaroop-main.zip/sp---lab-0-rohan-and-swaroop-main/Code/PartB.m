clc;
clear all;
close all;


%PartA


t= 0:0.01:1;

figure(1);

subplot(2,2,1);
y1 = sin(t);
plot(t,y1)
xlabel('Time')
ylabel('Amplitude')
title("Sine Wave Plot");


subplot(2,2,2);
y2 = exp(t);
plot(t,y2)
xlabel('Time')
ylabel('Amplitude')
title("Exponential Wave Plot");

subplot(2,2,3);
y3=exp(-abs(t));
plot(t,y3)
xlabel('Time')
ylabel('Amplitude')
title("Exponential Wave Plot");
 
subplot(2,2,4);
y4 = exp(-t.*t);
plot(t,y4)
xlabel('Time')
ylabel('Amplitude');
title("Exponential Wave Plot");



%PartB


T= -10:0.01:10;


figure(2);

subplot(2,2,1);
Y1 = sin(T);
plot(T,Y1)
xlabel('Time')
ylabel('Amplitude')
title("Sine Wave Plot");

subplot(2,2,2);
Y2 = exp(T);
plot(T,Y2)
xlabel('Time')
ylabel('Amplitude')
title("Exponential Wave Plot");

subplot(2,2,3);
Y3 = exp(-abs(T));
plot(T,Y3)
xlabel('Time')
ylabel('Amplitude')
title("Exponential Wave Plot");

subplot(2,2,4);
Y4 = exp(-(T.*T));
plot(T,Y4)
xlabel('Time')
ylabel('Amplitude')
title("Exponential Wave Plot");
