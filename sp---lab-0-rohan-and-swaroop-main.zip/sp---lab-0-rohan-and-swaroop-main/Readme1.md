#Assignment 0

##PartA

  Given to create a random 5×5 matrix and generate bottom right 3×3 Submatrix and then print sum of all entries of B.
  
###Generating Random Function
   
  Create a random matrix A by using rand function.
  rand(num1,num2) function creates a random num1×num2 matrix 
  Here num1,num2=5
    
###Generating Bottom Right 3×3 Matrix
 
  Fun(a:b,c:d) functin is used here 
  we have to print 3,4,5 Rows And 3,4,5 Coloumns
  Hence B= A(3:5,3:5)
    
###Summing Up All Entries
    Use sum(Fun,'all') function to sum up all entries of submatrix
    
    
##PartB

  Given to plot the given sine and exponential functions at given two time functions
  
  ###Procedure
  
  Procedure of plotting graph for a given time function
  
  1.Initialize time function.Lets Say 't'
  2.If we need to plot all the required graphs in one figure at a given time function use the subplot function
  3. Use plot(x,y) function to plot the function 
  4. Use xlabel and ylabel to label x and y axes
  5. Use title function to add title for the plot 
  
  
  
  
  
