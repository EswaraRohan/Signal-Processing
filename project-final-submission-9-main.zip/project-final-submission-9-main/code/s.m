function H=s(X,ts,p)
H=0;
N=length(X);
T=N*ts;
w0=2*pi/T;%sampling interval distance between consecutive samples  
wc=T/2;%cutoff that is pi/(sampling interval) or ws/2
n=ceil(-N/2):1:ceil(N/2)-1;
for k=1:N
    t=p-n(k);
    H=H+((X(k)*sin(wc*t*w0))/(pi*t*w0));
    % from sinc reconstruction and the paticular value is p*w0
end
H=abs(w0*H);
end