function delta = del(T,phi,h)
if abs(h)>= (pi/T)*(1-(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))/(1+(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))
    delta = sign(h)*((4/T)*acos((1-T*abs(h)/pi)/(sqrt(2)*(1+T*abs(h)/pi)))-(pi/T));
    
elseif (abs(h)< (pi/T)*(1-(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))/(1+(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))) && (abs(phi)<=pi/4)
        delta = (2/T)*(asin((2*(T/pi)*h(1+2*sin(phi)*sin(phi)))/(1+(T^2)*h^2/(pi)^2)));
    
elseif h == 0
    delta = 0;
    
elseif (abs(h)< (pi/T)*(1-(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))/(1+(sqrt(2)*sin(min(abs(phi),(pi/2-abs(phi))))))) && (abs(phi)>=pi/4)
        delta = (2/T)*(asin((2*(T/pi)*h(1+2*cos(phi)*cos(phi)))/(1+(T^2)*h^2/(pi)^2)));
end
end