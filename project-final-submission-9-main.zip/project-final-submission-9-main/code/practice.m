T=400;
A=1;
phi=0;
w=pi+pi/800;
t=0.5;
N=T/t;
n=0:N-1;
fn=A*exp(1j*w*n*t+1j*phi);
per=0.19;%percentsge of impulses
w1=zeros(size(1:5));
w2=zeros(size(1:5));
mse1=zeros(size(1:10));
mse2=zeros(size(1:10));
noise=rand(size(n));%generating random numbers 
for k=n+1
   if noise(k)<=per
       noise(k)=10;%converting the values less than per to impulses
   else
       noise(k)=0;%and others to zero
   end
end
variance=var(noise);
for l=1:10
    noise2=noise*(1/l);%impulse noise of variance variance *(1/l^2) 
for o=1:5
    noise1=noise;% adding a constant doesnt change the value of variance to snr does not change
    xn=fn+noise1;% adding pure impulse noise 
    [X,k0]=marginal_median(xn);
    pn=reccur(X,2,t,k0);
    w1(o)=(k0+pn)*(2*pi/T);
    ph=angle(X(k0-ceil(-N/2)+1));
    w2(o)=(2*pi*k0/T)+del(T,ph,h(X,t,k0,0));
end
  mse1(l)=mean((w1-w).^2);
  mse2(l)=mean((w2-w).^2);
  
end
l=1:10;
snr=(A^2).*(l.^2)/(2*(variance));
stem((snr),10*log10(mse1));
hold on ;
stem((snr),10*log10(mse2));
hold off;
legend("iterative","inverse");
ylabel("mse(db)");
xlabel("snr");
title('mse in both methode when N=1200');


