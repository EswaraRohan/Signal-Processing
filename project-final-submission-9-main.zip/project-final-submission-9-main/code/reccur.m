function pn=reccur(X,n,ts,k0)
N=length(X);
T=ts*N;
if n==0
    pn=0;
else
    t=reccur(X,n-1,ts,k0);
    pn=t-((T*h(X,ts,k0,t))/(2*pi));
end
end