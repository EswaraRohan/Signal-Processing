function H=h(X,ts,k0,p)
T=length(X)*ts;
t1=k0+p-(1/2);
t2=k0+p+(1/2);
h1=s(X,ts,t1);
h2=s(X,ts,t2);
H=(h2-h1)/(h2+h1);
H=pi*H*(1/T);
end