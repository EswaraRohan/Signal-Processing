function [Y,index]=marginal_median(xn)
N=length(xn);
p=ceil(-N/2):1:ceil(N/2)-1;
y=zeros(1,N);
Y=y;
for k=1:N
    P=p(k);
    t=(xn.*exp(-1j*2*pi*(1/N)*P*p));
Y(k)=median(real(t))+1j*median(imag(t));
end
[B,K]=sort(abs(Y),'descend');
index =K(1)+p(1)-1;
end 